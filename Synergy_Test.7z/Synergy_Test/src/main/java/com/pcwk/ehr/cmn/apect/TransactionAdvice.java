package com.pcwk.ehr.cmn.apect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.config.TransactionManagementConfigUtils;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;

import com.pcwk.ehr.cmn.PLog;

public class TransactionAdvice implements PLog {
	private PlatformTransactionManager transactionManager;

	public TransactionAdvice() {

	}

	public Object manageTransaction(ProceedingJoinPoint pjp) throws Throwable {

		Object retObj = null;
		TransactionStatus status = transactionManager.getTransaction(new DefaultTransactionAttribute());
		try {
			// 클래스명
			String className = pjp.getTarget().getClass().getName();

			// 메서드
			String methodName = pjp.getSignature().getName();

			log.debug("┌ className ()────────────────────────────┐ ");
			log.debug("│ methodName()                            │ ");

			// 대상메서드 실행
			retObj = pjp.proceed();

			transactionManager.commit(status);
		} catch (Throwable e) {

		}

		return retObj;
	}

	/**
	 * @param transactionManager the transactionManager to set
	 */
	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}
}
