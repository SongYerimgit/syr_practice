package com.pcwk.ehr.user.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.pcwk.ehr.user.dao.UserDaolmpl;

public class TestUserServiceException extends RuntimeException {
	Logger log = LogManager.getLogger(UserDaolmpl.class);
	
	public TestUserServiceException(String meString) {
		
		super(meString);
		log.debug("┌─────────────────────────────────────────────────────────┐");
		log.debug("│ TestUserServiceException()                              │"  + meString);
		log.debug("└─────────────────────────────────────────────────────────┘");

	}
}
