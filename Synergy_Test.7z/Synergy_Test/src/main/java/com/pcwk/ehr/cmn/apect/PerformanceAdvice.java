package com.pcwk.ehr.cmn.apect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;

import com.pcwk.ehr.cmn.PLog;



public class PerformanceAdvice implements PLog {
	public Object logExecutionTime(ProceedingJoinPoint pjp) throws Throwable {

		Object retObj = null;
		long start = System.currentTimeMillis();
		// 클래스명
		String className = pjp.getTarget().getClass().getName();

		// 메서드
		String methodName = pjp.getSignature().getName();
		
		//대상메서드 실행
		retObj = pjp.proceed();

		long end = System.currentTimeMillis();

		long executionTime = end - start;

		log.debug("┌ className ()────────────────────────────┐ ");
		log.debug("│ methodName()                            │ ");
		log.debug("^^^^^executionTime : " + executionTime + "ms");
		return retObj;

	}
}
