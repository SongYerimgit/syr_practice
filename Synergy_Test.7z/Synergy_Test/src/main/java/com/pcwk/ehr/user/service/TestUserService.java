/**
 * 
 */
package com.pcwk.ehr.user.service;

import com.pcwk.ehr.user.domain.UserDTO;

/**
 * @author USER
 *
 */
public class TestUserService extends UserServiceImpl {

	//pcwk04 등급 시 예외 발생.
	
	private String userId;

	/**
	 * @param userId
	 */
	public TestUserService(String userId) {
		super();
		this.userId = userId;
	}

	@Override
	protected void upgradeLevel(UserDTO user) {
		if(userId.equals(user.getUserId())) {
			throw new TestUserServiceException("예외가 발생 했습니다 . \n 사용자 아이디 : " +userId);
		}
		super.upgradeLevel(user);
	}
	
	
	
	
	
}
