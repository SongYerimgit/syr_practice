package com.pcwk.ehr.user.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.pcwk.ehr.user.dao.UserDao;
import com.pcwk.ehr.user.domain.Level;
import com.pcwk.ehr.user.domain.UserDTO;

import org.springframework.transaction.support.TransactionSynchronizationManager;

public class UserServiceImpl implements UserService {
	Logger log = LogManager.getLogger(getClass());

	private MailSender mailSender;


	private static UserDao userDao;



	public UserServiceImpl() {
	}

	/**
	 * @param mailSender the mailSender to set
	 */
	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}





	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	private void sendUpgradeEmail(UserDTO user) {
		// 보내는 사람
		// 받는사람
		// 제목
		// 내용

		try {
			SimpleMailMessage message = new SimpleMailMessage();
			// 보내는 사람
			message.setFrom("syl2549@naver.com");

			// 받는 사람
			message.setTo(user.getEmail());

			// 제목 :
			message.setSubject("등업 안내");

			// {}님의 등급이{GOLD}로 등업되었습니다.
			String contexts = user.getName() + "님의 등급이" + user.getGrade() + "로 등업 되었습니다.";

			log.debug(contexts);
			message.setText(contexts);

			mailSender.send(message);

		} catch (Exception e) {
			log.debug("┌─────────────────────────────────────────────────────────┐");
			log.debug("│ sendUpgradeEmail.Exception()                            │" + e.getMessage());
			log.debug("└─────────────────────────────────────────────────────────┘");

		}
	}

	@Override
	public List<UserDTO> doRetrieve(UserDTO param) {
		return userDao.doRetrieve(param);
	}

	@Override
	public int doDelete(UserDTO param) {
		return userDao.doDelete(param);
	}

	@Override
	public int doUpdate(UserDTO param) {
		return userDao.doUpdate(param);
	}

	UserDTO doSelectOne(UserDTO param) throws SQLException {
		return userDao.doSelectOne(param);
	}

	// 최초 회원 가입 시 레벨 베이직
	public static int doSave(UserDTO param) throws SQLException {
		if (null == param.getGrade()) {
			param.setGrade(Level.BASIC);
		}
		return userDao.doSave(param);
	}

	// 1. 현재 레벨이 무엇인지 파악하는 로직
	// 2. 등업 조건
	private boolean canUpgardeLevel(UserDTO user) {
		Level currentLevel = user.getGrade();
		switch (currentLevel) {
		case BASIC:
			return (user.getLogin() >= MIN_LOGIN_COUNT_FOR_SILVER);
		case SILVER:
			return (user.getRecommend() >= MIN_RECOMMEND_FOR_GOLD);
		case GOLD:
			return false;
		default:
			throw new IllegalArgumentException("Unknown Level: " + currentLevel);
		}
	}

	// 다음 단계의 레벨은 무엇이며, 업그레이드를 위한 작업은 뭐인지
	protected void upgradeLevel(UserDTO user) {
		if (Level.BASIC == user.getGrade()) {
			user.setGrade(Level.SILVER);
		} else if (Level.SILVER == user.getGrade()) {
			user.setGrade(Level.GOLD);
		}
		userDao.doUpdate(user);

		// mail전송
		sendUpgradeEmail(user);
	}

	
	
	// 전체 회원을 대상으로 등업
	@Override
	public void upgradeLevels() throws SQLException {
			// 전체 회원을
			List<UserDTO> users = userDao.getAll();
			// 반복문: 등업 대상자
			for (UserDTO user : users) {

				if (canUpgardeLevel(user)) {
					upgradeLevel(user);
				}
			}
	}
}
