package com.pcwk.ehr.user;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.sist.ehr.user.dao.UserDao;
import com.sist.ehr.user.domain.UserDTO;


@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {"classpath:/applicationContext.xml"})

public class UserDaoTest {
	@Autowired
	UserDao dao;
	
	UserDTO dto01;
	UserDTO dto02;
	UserDTO dto03;
	
	@Autowired
	ApplicationContext context;
	
	Logger log = LogManager.getLogger(getClass());
	
	@Before
	public void setUp() throws Exception {

		log.debug("context:" + context);

		
		dto01 = new UserDTO("pcwk01", "이상무01", "4321", "사용안함");
		dto02 = new UserDTO("pcwk02", "이상무02", "4321a", "사용안함");
		dto03 = new UserDTO("pcwk03", "이상무03", "a4321", "사용안함");
		
		
		// 메모리에 생성된 객체를 추출
		dao = context.getBean("userDao", UserDao.class);
		log.debug("dao:" + dao);
	}

	@After
	public void tearDown() throws Exception {
		log.debug("---------------------------------");
		log.debug("@After");
		log.debug("---------------------------------");
	}
	
	@Test(expected = NullPointerException.class)
	public void getFailure( ) throws SQLException {
		//매번 동일한 결과가 도출 되도록 작성
		//1. 전체 삭제
		//2. 단건 등록
		//3. 단건 조회
		
		
		//1.
		dao.deleteAll( );
		
		
		//2.
		dao.doSave(dto01);
		int count = dao.getCount();
		assertEquals(1,  count);  //1의 의미는 조회 건수
		
		
		
		String unknownId = dto01.getUserId() + "99";
		dto01.setUserId(unknownId);
		
		UserDTO outVO = dao.doSelectOne(dto01);
		
	}

	@Test
	public void addAndGet() throws SQLException {
		//매번 동일한 결과가 도출 되도록 작성
		//1. 전체 삭제
		//2. 단건 등록
		//2.1 전체 건수 조회
		//3. 단건 조회
		//4. 비교
		
		
		//1.
		dao.deleteAll();
		
		//2.
		int flag = dao.doSave(dto01);
		assertEquals(1, flag);
		
		//2.1
		int count = dao.getCount();
		assertEquals(count, 1);
		
		
		dao.doSave(dto02);
		count = dao.getCount();
		assertEquals(count, 2);  //2의 의미는 조회 건수
		
		
		dao.doSave(dto03);
		count = dao.getCount();
		assertEquals(count, 3);  //3의 의미는 조회 건수
		

		//3. 
		UserDTO outVO = dao.doSelectOne(dto01);
		assertNotNull(outVO);
		inSameUser(outVO,dto01);
		
		UserDTO outVO2 = dao.doSelectOne(dto02);
		assertNotNull(outVO2);
		inSameUser(outVO2,dto02);
		
		UserDTO outVO3 = dao.doSelectOne(dto03);
		assertNotNull(outVO3);
		inSameUser(outVO2,dto03);
		
		
		//4.
		assertEquals(outVO.getUserId(), dto01.getUserId());
		assertEquals(outVO.getName(), dto01.getName());
		assertEquals(outVO.getPassword(), dto01.getPassword());
	}
	
	
	public void inSameUser(UserDTO outVO, UserDTO dto01) {
		 
		
	}
	
	
	
	
	
	
	
	
	
	
	

}
