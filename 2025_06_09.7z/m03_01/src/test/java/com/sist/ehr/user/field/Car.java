package com.sist.ehr.user.field;

import org.junit.jupiter.api.AutoClose;
import org.springframework.stereotype.Component;

@Component
public class Car {
	@AutoClose
	private Engine engine;
	
	
	public void drive() {
		engine.start();
		System.out.println("Car 운전 붕붕!");
	}
}
