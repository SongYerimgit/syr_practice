package com.sist.ehr.user.domain;

public class UserDTO {
	//UserDTO
	//-----------------
	//전역변수
	//default 생성자
	//인자있는 생성자
	//get/setters
	//toString()
	private String  userId   ;//사용자ID
	private String  name     ;//이름
	private String  password ;//비밀번호
	private String  redDt    ;//등록일
	
	public UserDTO() {}

	
	/**
	 * @param userId
	 * @param name
	 * @param password
	 * @param redDt
	 */
	public UserDTO(String userId, String name, String password, String redDt) {
		this.userId = userId;
		this.name = name;
		this.password = password;
		this.redDt = redDt;
	}


	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the redDt
	 */
	public String getRedDt() {
		return redDt;
	}

	/**
	 * @param redDt the redDt to set
	 */
	public void setRedDt(String redDt) {
		this.redDt = redDt;
	}

	@Override
	public String toString() {
		return "UserDTO [userId=" + userId + ", name=" + name + ", password=" + password + ", redDt=" + redDt + "]";
	}
	
	
	
}
