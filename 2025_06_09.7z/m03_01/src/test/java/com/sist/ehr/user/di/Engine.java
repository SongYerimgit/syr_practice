/**
 * Package Name : com.pcwk.ehr.user.di <br/>
 * 파일명: Engine.java <br/>
 */
package com.sist.ehr.user.di;

/**
 * @author user
 *
 */
public class Engine {

	
	public void start() {
		System.out.println("Engine 시동!");
	}
}
