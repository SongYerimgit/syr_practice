package com.sist.ehr.user.di.setter;

public class Main {

	public static void main(String[] args) {
		Engine engine = new Engine();
		
		Car car = new Car();
		car.setEngine(engine); // setter Injection
		
		car.drive();
	}

}
