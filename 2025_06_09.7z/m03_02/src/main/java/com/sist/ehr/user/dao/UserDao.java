package com.sist.ehr.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.sist.ehr.user.domain.UserDTO;

public class UserDao {

    ConnectionMaker connectionMaker;

    public UserDao() {}    //Default 생성자 필수

    public UserDao(ConnectionMaker connectionMaker) {
        this.connectionMaker = connectionMaker;
        System.out.println("connectionMaker:" + connectionMaker);
    }

    public void setConnectionMaker(ConnectionMaker connectionMaker) {
        this.connectionMaker = connectionMaker;
    }

    /**
     * 단건조회
     */
    public UserDTO doSelectOne(UserDTO param) throws ClassNotFoundException, SQLException {
        UserDTO outVO = null;

        Connection conn = this.connectionMaker.makeConnection();
        System.out.println("1.conn:" + conn);

        StringBuilder sb = new StringBuilder(200);
        sb.append(" SELECT                 \n");
        sb.append("     USER_ID,           \n");
        sb.append("     NAME,              \n");
        sb.append("     PASSWORD,          \n");
        sb.append("     TO_CHAR(RED_DT,'YYYY-MM-DD') AS RED_DT_STR \n");
        sb.append(" FROM                   \n");
        sb.append("     MEMBER             \n");
        sb.append(" WHERE USER_ID = ?      \n");

        System.out.println("2.sql:\n" + sb.toString());

        PreparedStatement pstmt = conn.prepareStatement(sb.toString());
        System.out.println("3.pstmt:" + pstmt);
        System.out.println("3.1 param:" + param);

        pstmt.setString(1, param.getUserId());

        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            outVO = new UserDTO();
            outVO.setUserId(rs.getString("USER_ID"));
            outVO.setName(rs.getString("NAME"));
            outVO.setPassword(rs.getString("PASSWORD"));
            outVO.setRedDt(rs.getString("RED_DT_STR"));

            System.out.println("4.1 outVO:" + outVO);
        }

        rs.close();
        pstmt.close();
        conn.close();

        return outVO;
    }

    /**
     * 단건등록
     */
    public int doSave(UserDTO param) throws ClassNotFoundException, SQLException {
        int flag = 0;

        Connection conn = this.connectionMaker.makeConnection();
        System.out.println("1.conn:" + conn);

        StringBuilder sb = new StringBuilder(200);
        sb.append(" INSERT INTO MEMBER ( \n");
        sb.append("     USER_ID,         \n");
        sb.append("     NAME,            \n");
        sb.append("     PASSWORD,        \n");
        sb.append("     RED_DT           \n");
        sb.append(" ) VALUES ( ?,        \n");
        sb.append("           ?,         \n");
        sb.append("           ?,         \n");
        sb.append("           SYSDATE )  \n");

        System.out.println("2.sql:\n" + sb.toString());

        PreparedStatement pstmt = conn.prepareStatement(sb.toString());
        System.out.println("3.pstmt:" + pstmt);
        System.out.println("3.1 param:" + param);

        pstmt.setString(1, param.getUserId());
        pstmt.setString(2, param.getName());
        pstmt.setString(3, param.getPassword());

        flag = pstmt.executeUpdate();
        System.out.println("4.flag:" + flag);

        pstmt.close();
        conn.close();

        return flag;
    }
}
