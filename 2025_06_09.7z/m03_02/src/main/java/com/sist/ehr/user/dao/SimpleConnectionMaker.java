package com.sist.ehr.user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SimpleConnectionMaker {
	
	/*
	 * DB 연결
	 * 
	 * 
	 */
	public Connection makeNewConnection() throws SQLException, ClassNotFoundException {
		Connection conn = null;
		
		// 1.
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		// 2.
		String url = "jdbc:oracle:thin:@192.168.100.154:1521:XE";
		String user = "scott";
		String password = "pcwk";
		conn = DriverManager.getConnection(url, user, password);
		
		System.out.println("1.conn : " + conn);
		
		
		return conn;
	
		
	}
}
